# Classification Example


## Usage

```bash
labelme data_annotated --flags flags.txt --nodata
```

<img src=".readme/annotation_cat.jpg" width="100%" />
<img src=".readme/annotation_dog.jpg" width="100%" />
